package Flipkart;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RealmePhonesPage {
	WebDriver driver;
	public RealmePhonesPage(WebDriver driver) {
		this.driver=driver;
	}
	/*public void Sort(){
		Select sort = new Select(driver.findElement(By.xpath("//div[@class='_5THWM1']")));
		sort.selectByVisibleText("Price -- High to Low");

	}
	public void price(){
		List<WebElement> lowbooks = driver.findElements(By.xpath("//div[@class='product-summary']/div[@class='title']/a"));
	}
	
	public Item1 select1() {
		//Select price = new Select(driver.findElement(By.className("_2GoDe3")));
		//price.selectByVisibleText("realme C25Y (Glacier Blue, 64 GB)");

		driver.findElement(By.xpath("//body/div[1]/div/div[3]/div/div[2]/div[5]/div/div/div/a/div[2]/div[1]/div[1]")).click();
		return PageFactory.initElements(driver, Item1.class);
	}*/
	public Item1 select1() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.xpath("//body/div[1]/div/div[3]/div/div[2]/div[2]/div/div/div/a/div[2]/div[1]/div[1]")).click();
		return PageFactory.initElements(driver, Item1.class);
	}
	
	public Item2 select2() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.xpath("//body/div[1]/div/div[3]/div/div[2]/div[5]/div/div/div/a/div[2]/div[1]/div[1]")).click();
		return PageFactory.initElements(driver, Item2.class);
	}
	
	public Item3 select3() {

		driver.findElement(By.xpath("//body/div[1]/div/div[3]/div/div[2]/div[6]/div/div/div/a/div[2]/div[1]/div[1]")).click();
		return PageFactory.initElements(driver, Item3.class);

	}
	public Item4 select4() {

		driver.findElement(By.xpath("//body/div[1]/div/div[3]/div/div[2]/div[7]/div/div/div/a/div[2]/div[1]/div[1]")).click();
		return PageFactory.initElements(driver, Item4.class);

	}
	public void driverchange1() {

		String parent=driver.getWindowHandle();
		Set<String> allWindows=driver.getWindowHandles();
		ArrayList<String> tabs=new ArrayList<>(allWindows);
		driver.switchTo().window(tabs.get(4));
		//driver.close();
		}
	public void driverchange2() {
		//driver.close();
		String parent=driver.getWindowHandle();
		Set<String> allWindows=driver.getWindowHandles();
		ArrayList<String> tabs=new ArrayList<>(allWindows);
		driver.switchTo().window(tabs.get(3));
	}
	public void driverchange3() {
		//driver.close();
		String parent=driver.getWindowHandle();
		Set<String> allWindows=driver.getWindowHandles();
		ArrayList<String> tabs=new ArrayList<>(allWindows);
		driver.switchTo().window(tabs.get(2));
	}
	public void driverchange4() {
		//driver.close();
		String parent=driver.getWindowHandle();
		Set<String> allWindows=driver.getWindowHandles();
		ArrayList<String> tabs=new ArrayList<>(allWindows);
		driver.switchTo().window(tabs.get(1));
	}
}



